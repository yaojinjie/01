#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	printf("����printf\n");
	printf("    *    \n");
	printf("   ***   \n");
	printf("  *****  \n");
	printf(" ******* \n");
	printf("*********\n");
	
	printf("\n");

	printf("�@��printf\n");
	printf("    *    \n   ***   \n  *****  \n ******* \n*********\n");
	
	system("pause");
	return 0;
}